let BASE_URL = "https://baotangtruyen24.com";


try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}