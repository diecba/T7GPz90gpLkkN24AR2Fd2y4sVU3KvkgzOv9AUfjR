function execute() {
    return Response.success([
        {title: "Mới Cập Nhật", input: "0", script: "gen.js"},
        {title: "Truyện Web Làm", input: "1", script: "gen.js"},
    ]);
}